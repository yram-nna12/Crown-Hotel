<?php
// Handle cookie setup on form submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$username = $_POST['username'];
$password = $_POST['password'];
$remember = isset($_POST['remember']);

if ($remember) {
// Set cookies for 7 days
setcookie("username", $username, time() + (86400 * 7), "/");
setcookie("password", $password, time() + (86400 * 7), "/");
} else {
// Clear cookies
setcookie("username", "", time() - 3600, "/");
setcookie("password", "", time() - 3600, "/");
}

echo "<p>Login successful.</p>";
}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="./style.css">
<title>Login Module</title>
</head>
<body>

<form method="POST">
<label>Username</label><br>
<input type="text" name="username" value="<?php echo isset($_COOKIE['username']) ? $_COOKIE['username'] : ''; ?>" required><br>

<label>Password</label><br>
<input type="password" name="password" value="<?php echo isset($_COOKIE['password']) ? $_COOKIE['password'] : ''; ?>" required><br>

<label><input type="checkbox" name="remember" <?php echo (isset($_COOKIE['username'])) ? 'checked' : ''; ?>> Remember Me</label><br><br>

<input type="submit" value="Submit">
</form>

</body>
</html>