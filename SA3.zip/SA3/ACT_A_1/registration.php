<!DOCTYPE html>
<html>
<head>
  <title>Registration Module</title>
  <link rel="stylesheet" href="./style.css">
</head>
<body>

<form method="POST">
  <h2>Personal Information</h2>

  <div>
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="fname" pattern="[A-Za-z\s]+" title="Letters only" required>
  </div>

  <div>
    <label for="mname">Middle Name</label>
    <input type="text" id="mname" name="mname" pattern="[A-Za-z\s]+" title="Letters only" required>
  </div>

  <div>
    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lname" pattern="[A-Za-z\s]+" title="Letters only" required>
  </div>

  <div>
    <label for="username">Username</label>
    <input type="text" id="username" name="username" required>
  </div>

  <div>
    <label for="password">Password</label>
    <input type="password" id="password" name="password" required>
  </div>

  <div>
    <label for="confirm_password">Confirm Password</label>
    <input type="password" id="confirm_password" name="confirm_password" required>
  </div>

  <div>
    <label for="birthday">Birthday</label>
    <input type="text" id="birthday" name="birthday" placeholder="e.g. January 30 1993" required>
  </div>

  <div>
    <label for="email">Email</label>
    <input type="email" id="email" name="email" required>
  </div>

  <div>
    <label for="contact">Contact Number</label>
    <input type="text" id="contact" name="contact" pattern="[0-9]{11}" maxlength="11" title="Enter 11-digit number" required>
  </div>

  <input type="submit" value="Submit">


  <?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = htmlspecialchars($_POST['fname']);
    $mname = htmlspecialchars($_POST['mname']);
    $lname = htmlspecialchars($_POST['lname']);
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password'];
    $birthday = htmlspecialchars($_POST['birthday']);
    $email = htmlspecialchars($_POST['email']);
    $contact = htmlspecialchars($_POST['contact']);

    if (!preg_match("/^[a-zA-Z\s]+$/", $fname) ||
        !preg_match("/^[a-zA-Z\s]+$/", $mname) ||
        !preg_match("/^[a-zA-Z\s]+$/", $lname)) {
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      echo "<p class='error'>Invalid email format.</p>";
    } elseif (!preg_match("/^[0-9]{11}$/", $contact)) {
      echo "<p class='error'>Contact number should contain exactly 11 digits.</p>";
    } elseif ($password !== $confirm) {
      echo "<p class='error'>Password and confirm password are not the same.</p>";
    } else {
      echo "<div class='result'>
        <strong>Submitted Information:</strong><br>
        First Name: $fname<br>
        Middle Name: $mname<br>
        Last Name: $lname<br>
        Username: $username<br>
        Birthday: $birthday<br>
        Email: $email<br>
        Contact Number: $contact
      </div>";
    }
  }
  ?>
</form>

</body>
</html>
